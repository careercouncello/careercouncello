function vishaln() {
  var c = b.toString();
  localStorage.setItem("SCIENCE AND TECHNOLOGY", c);
  var r = 1;
  var pqr = r.toString();
  localStorage.setItem("ale", pqr);

  document.write(
    "<h1 allign='centre'>Congratulations You Have Successfully Completed the 1st Section</h1>"
  );
  document.write(
    "<h1 allign='centre'>Click on the button to reach catagory & start another section</h1>"
  );
  document.write(
    '<button id="mybutton"><a href="catagory.html">Catagory</a></button>'
  );
}
