function populate() {
  if (quiz.isEnded()) {
    showScores();
  } else {
    // show question
    var element = document.getElementById("question");
    element.innerHTML = quiz.getQuestionIndex().text;

    // show options
    var choices = quiz.getQuestionIndex().choices;
    for (var i = 0; i < choices.length; i++) {
      var element = document.getElementById("choice" + i);
      element.innerHTML = choices[i];
      guess("btn" + i, choices[i]);
    }

    showProgress();
  }
}

function guess(id, guess) {
  var button = document.getElementById(id);
  button.onclick = function() {
    quiz.guess(guess);
    populate();
  };
}

function showProgress() {
  var currentQuestionNumber = quiz.questionIndex + 1;
  var element = document.getElementById("progress");
  element.innerHTML =
    "Question " + currentQuestionNumber + " of " + quiz.questions.length;
}
var b;
function showScores() {
  var gameOverHTML = "<h1>Result</h1>";
  gameOverHTML += "<h2 id='score'> Your scores: " + quiz.score + "</h2>";
  b = quiz.score;
  var element = document.getElementById("quiz");
  element.innerHTML = gameOverHTML;
  let div = document.createElement("button");
  div.className = "btnmq";

  div.innerHTML = "Submit";

  document.body.append(div);

  div.setAttribute("onclick", "vishaln();");
}

// create questions
var questions = [
  new Question(
    "Do you have interest in knowing functionality of different human organs?",
    ["Yes", "No", "Not Sure", "C"],
    "Yes"
  ),
  new Question(
    "Do you like to read different biological books?",
    ["Yes", "No", "Not Sure", "XML"],
    "Yes"
  ),
  new Question(
    "Do you like to treat your family members with different home remedies?",
    ["Yes", "No", "Not Sure", "4"],
    "Yes"
  ),
  new Question(
    "Would you like to treat stray animals from different streets?",
    ["Yes", "No", "Not Sure", "4"],
    "Yes"
  ),
  new Question(
    "Would you like to collect information about different species of plants and make research on them?",
    ["Yes", "No", "Not Sure", "4"],
    "Yes"
  ),
  new Question(
    "Do you suggest your family members for regular health cheakup?",
    ["Yes", "No", "Not Sure", "4"],
    "Yes"
  ),
  new Question(
    "Do you apply first aid to any person suffering from some illness?",
    ["Yes", "No", "Not Sure", "4"],
    "Yes"
  ),
  new Question(
    "Glands located in mouth which helps in digestion process are?",
    ["Larynx", "Pharynx", "Salivary glands", ""],
    "Salivary glands"
  ),
  new Question(
    "How many basic sensory organs are there in human body?",
    ["Cash is received", "Revenues are earned", "both", "4"],
    "Revenues are earned"
  ),
  new Question(
    "what sensory function do the ears provide other than hearing?",
    ["radiation", "balance", "smell", "4"],
    "balance"
  ),
  new Question(
    "the study of function is called?",
    ["ecology", "anatomy", "physiology", "4"],
    "physiology"
  ),
  new Question(
    "the proteins having three diamensional structures are called?",
    ["primery", "tertiary", "quaternary", "4"],
    "tertiary"
  ),
  new Question(
    "what is the study of animal life called?",
    ["geology", "zoology", "epidemiology", "4"],
    "zoology"
  ),
  new Question(
    "______ is a potential sources of energy?",
    ["proteins", "vitamins", "carbohydrates", "4"],
    "carbohydrates"
  ),
  new Question(
    "which of the following possess a double helix structure?",
    ["Ribo-nucleic acid", "Deoxyribo-nucleic acid", "none of these", "4"],
    "Deoxyribo-nucleic acid"
  ),
  new Question(
    "How many sex chromosome are there in human body?",
    ["20", "24", "26", "22"],
    "22"
  ),
  new Question(
    "Which of the following is a part of female reproductive system?",
    ["Uterus", "Vas deferens", "testicles", "4"],
    "Uterus"
  ),
  new Question("?", ["Yes", "No", "Not Sure", "4"], "Yes"),
  new Question("?", ["Yes", "No", "Not Sure", "4"], "Yes"),
  new Question("?", ["Yes", "No", "Not Sure", "4"], "Yes")
];

// create quiz
var quiz = new Quiz(questions);

// display quiz
populate();
