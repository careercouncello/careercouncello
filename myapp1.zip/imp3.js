function vishaln() {
  var f = b.toString();
  localStorage.setItem("ARTS&LITTERATURE", f);
  var u = 1;
  var cd = u.toString();
  localStorage.setItem("ale3", cd);
  document.write(
    "<h1>Congratulations You Have Successfully Completed the 1st Section</h1>"
  );
  document.write("<h1>Click on the button for next section</h1>");
  document.write(
    '<button id="mybutton"><a href="catagory.html">NEXT SECTION</a></button>'
  );
}
