function vishaln() {
  var e = b.toString();
  localStorage.setItem("COMMERCE", e);
  var t = 1;
  var vw = t.toString();
  localStorage.setItem("ale2", vw);
  document.write(
    "<h1>Congratulations You Have Successfully Completed the 1st Section</h1>"
  );
  document.write("<h1>Click on the button for next section</h1>");
  document.write(
    '<button id="mybutton"><a href="catagory.html">NEXT SECTION</a></button>'
  );
}
