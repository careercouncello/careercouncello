function vishaln() {
  var g = b.toString();
  localStorage.setItem("FOODANDAGRICULTURE", g);
  var v = 1;
  var pq = v.toString();
  localStorage.setItem("ale4", pq);
  document.write(
    "<h1>Congratulations You Have Successfully Completed the APPTITUDE TEST</h1>"
  );
  document.write("<h1>Click on the button for RESULT</h1>");
  document.write(
    '<button id="mybutton"><a href="catagory.html">Catagory</a></button>'
  );
}
