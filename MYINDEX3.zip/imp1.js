function vishaln() {
  var d = b.toString();
  localStorage.setItem("BIOLOGY", d);
  var s = 1;
  var stu = s.toString();
  localStorage.setItem("ale1", stu);
  document.write(
    "<h1>Congratulations You Have Successfully Completed the 1st Section</h1>"
  );
  document.write("<h1>Click on the button for next section</h1>");
  document.write(
    '<button id="mybutton"><a href="catagory.html">NEXT SECTION</a></button>'
  );
}
